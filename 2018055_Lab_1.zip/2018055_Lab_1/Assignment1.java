import java.util.*;

public class Assignment1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        ArrayList<Student> allstudents = new ArrayList<>();
        ArrayList<Company> allcompanies = new ArrayList<>();
        for (int i=0;i<n;i++){
            float cgpa = input.nextFloat();
            String branch = input.next();
            allstudents.add(new Student(cgpa,branch));
        }
        int query=1;
        int flag=0;
        while (query!=0 && flag==0){
            System.out.print("Enter query ");
            query = input.nextInt();
            if (query==1){
                System.out.print("Company Name : ");
                String companyname = input.next();
                Company newcompany = new Company(companyname,allstudents);
                allcompanies.add(newcompany);
                System.out.print("Number of Eligible Courses : ");
                int courses = input.nextInt();
                for (int i=0;i<courses;i++){
                    newcompany.courses.add(input.next());
                }
                System.out.print("Number of required students ");
                int reqdstudent = input.nextInt();
                System.out.println(reqdstudent);
                newcompany.reqdstudents=reqdstudent;
                newcompany.display();
            }else if(query==2){
                for (int i=0;i<allstudents.size();i++){
                    if (allstudents.get(i).placed && allstudents.get(i).removed==false){
                        allstudents.get(i).removed=true;
                        Student.left--;
                    }
                }
            }else if(query==3){
                for (int i=0;i<allcompanies.size();i++){
                    if (allcompanies.get(i).status.equals("CLOSED") && allcompanies.get(i).removed==false){
                        allcompanies.get(i).removed=true;
                    }
                }
            }else if(query==4){
                int count=0;
                for (int i=0;i<allstudents.size();i++){
                    if (allstudents.get(i).placed==false){
                        count++;
                    }
                }
                System.out.println("Number of Students left : "+count);
            }else if(query==5){
                for (int i=0;i<allcompanies.size();i++){
                    if (allcompanies.get(i).status.equals("OPEN")){
                        System.out.println(allcompanies.get(i).name);
                    }
                }
            }else if(query==6){
                String companyname = input.next();
                for (int i=0;i<allcompanies.size();i++){
                    if (allcompanies.get(i).name.equals(companyname)){
                        allcompanies.get(i).selectstudents();
                        break;
                    }
                }
            }else if(query==7){
                String companyname = input.next();
                for (int i=0;i<allcompanies.size();i++){
                    if (allcompanies.get(i).name.equals(companyname)){
                        System.out.println("Name : "+allcompanies.get(i).name);
                        System.out.println("Course Criteria -");
                        for (int j=0;j<allcompanies.get(i).courses.size();j++){
                            System.out.println(allcompanies.get(i).courses.get(j));
                        }
                        System.out.println("Number of Required Students : "+allcompanies.get(i).reqdstudents);
                        System.out.println("Application Status : "+allcompanies.get(i).status);
                        break;
                    }
                }
            }else if(query==8){
                int roll = input.nextInt();
                if (allstudents.get(roll-1).removed){
                    System.out.println("No student with the given roll no. has an account");
                }else{
                    allstudents.get(roll-1).display();
                }
            }else if(query==9){
                int roll = input.nextInt();
                if (allstudents.get(roll-1).removed){
                    System.out.println("No student with the given roll no. has an account");
                }else {
                    for (String key : allstudents.get(roll - 1).roundscores.keySet()) {
                        System.out.println("" + key + " " + allstudents.get(roll - 1).roundscores.get(key));
                    }
                }
            }
            flag=1;
            for (int i=0;i<allstudents.size();i++){
                if (allstudents.get(i).placed==false){
                    flag=0;
                    break;
                }
            }
        }
    }
}

class Student{
    public static int left;
    private static int totalstudents;
    public int rollno;
    public final float cgpa;
    public HashMap<String, Float> roundscores = new HashMap<>();
    public final String branch;
    public boolean placed = false;
    public String job;
    public boolean removed = false;
    Student(float cgpa, String branch) {
        this.cgpa = cgpa;
        this.branch = branch;
        totalstudents++;
        left++;
        this.rollno=totalstudents;
    }
    public void display(){
        System.out.println("Roll number : "+this.rollno);
        System.out.println("CGPA : "+this.cgpa);
        System.out.println("Branch : "+this.branch);
        if(placed){
            System.out.println("Placement Status : Placed");
            System.out.println("Company : "+this.job);
        }else{
            System.out.println("Placement Status : Not Placed");
        }
    }
}

class Company{
    private static int totalcompanies;
    public final String name;
    public ArrayList<String> courses = new ArrayList();
    public ArrayList<Student> students = new ArrayList();
    public int reqdstudents;
    public boolean removed = false;
    String status = "OPEN";
    Company(String name, ArrayList<Student> students) {
        this.name = name;
        this.students = students;
        totalcompanies++;
    }
    public void addcourse(String c){
        this.courses.add(c);
    }
    public void display() {
        System.out.println(this.name);
        System.out.println("Course Criteria");
        for (int i = 0; i < this.courses.size(); i++) {
            System.out.println(this.courses.get(i));
        }
        System.out.println("Number of Required Students = " + this.reqdstudents);
        System.out.println("Application Status = " + this.status);
        addscores();
    }
    public void addscores(){
        Scanner inputscores = new Scanner(System.in);
        for (int i=0;i<this.students.size();i++){
            for (int j=0;j<this.courses.size();j++){
                //System.out.println(students.get(i).branch.equals(this.courses.get(j)));
                if ((students.get(i).branch).equals(this.courses.get(j))){
                    System.out.println("Enter score for roll no."+students.get(i).rollno);
                    students.get(i).roundscores.put(this.name,inputscores.nextFloat());
                    break;
                }
            }
        }
    }
    public void selectstudents(){
        if (this.reqdstudents>=Student.left){
            Student.left=0;
            this.status="CLOSED";
            for (int i=0;i<students.size();i++){
                if (students.get(i).removed==false){
                    students.get(i).placed=true;
                    students.get(i).job=this.name;
                }
            }
        }else{
            this.status="CLOSED";
            ArrayList<Student> tobeselected = new ArrayList<>();
            for (int i=0;i<students.size();i++){
                if (students.get(i).placed==false && students.get(i).removed==false && students.get(i).roundscores.get(this.name)!=null){
                      tobeselected.add(students.get(i));
                }
            }
            for (int i=0;i<tobeselected.size();i++){
                for (int j=0;j<tobeselected.size()-i-1;j++){
                    if (tobeselected.get(j).roundscores.get(this.name)<tobeselected.get(j+1).roundscores.get(this.name)){
                        Studentwrapper s1 = new Studentwrapper(tobeselected.get(j));
                        Studentwrapper s2 = new Studentwrapper(tobeselected.get(j+1));
                        //swapstudents(s1,s2);
                        tobeselected.set(j+1,s1.s);
                        tobeselected.set(j,s2.s);
                    }else if(tobeselected.get(j).roundscores.get(this.name).equals(tobeselected.get(j+1).roundscores.get(this.name))){
                        if (tobeselected.get(j).cgpa<tobeselected.get(j+1).cgpa){
                            Studentwrapper s1 = new Studentwrapper(tobeselected.get(j));
                            Studentwrapper s2 = new Studentwrapper(tobeselected.get(j+1));
                            //swapstudents(s1,s2);
                            tobeselected.set(j+1,s1.s);
                            tobeselected.set(j,s2.s);
                        }
                    }
                    //System.out.println(tobeselected.toString());
                }
            }
            int i=0;
            System.out.println("Roll number of selected students - ");
            while (this.reqdstudents!=0){
                System.out.println(tobeselected.get(i).rollno);
                tobeselected.get(i).placed=true;
                tobeselected.get(i).job=this.name;
                this.reqdstudents--;
                i++;
            }
        }
    }
    public void swapstudents(Studentwrapper s1,Studentwrapper s2){
        Student temp = s2.s;
        s2.s=s1.s;
        s1.s=temp;
    }
}

class Studentwrapper{
    Student s;
    Studentwrapper(Student s){
        this.s=s;
    }
}
