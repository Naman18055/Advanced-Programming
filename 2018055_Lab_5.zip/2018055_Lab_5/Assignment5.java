import java.util.*;
public class Assignment5 {
    public static void main(String[] args) {
        Start_game start = new Start_game();
        start.play();
    }
}

class Start_game{
    Scanner input = new Scanner(System.in);
    public void play(){
        System.out.println("Enter total number of tiles on the race track (length) - ");
        int length = input.nextInt();
        Game_layout map = new Game_layout(length);
        map.draw_map();
        System.out.println("Enter the player name - ");
        String name = input.next();
        User user = new User(name);
        try {
            user.start();
        }catch (GameWinnerException e){
            System.out.println(e.getMessage());
            System.out.println(user.getName()+" wins the race in "+Dice.getTotal_rolls()+" Rolls.");
            System.out.println("Total Snake Bites : "+user.getSnake_bites());
            System.out.println("Total Cricket Bites : "+user.getCricket_bites());
            System.out.println("Total Vulture Bites : "+user.getVulture_bites());
            System.out.println("Total Trampolines : "+user.getTrampolines());
        }
    }
}

class User{
    private final String name;
    private int curr_tile = 1;
    private int snake_bites = 0;
    private int cricket_bites = 0;
    private int vulture_bites = 0;
    private int trampolines = 0;
    ArrayList<Tile> track = Game_layout.getTrack();
    int length = track.size() + 1;
    User(String name){
        this.name = name;
    }
    public void start() throws GameWinnerException{
        System.out.println("Starting the game with "+this.name+" at Tile-1.");
        System.out.println("Control transferred to Computer for rolling the Dice for "+this.name);
        System.out.println("Game Started =====================================================>");
        Dice dice = new Dice(6);
        //System.out.println("Total Tiles - "+this.length);
        while (this.curr_tile!=length){
            if (Dice.getTotal_rolls()>500000){
                System.out.println("You cant win this shit");
                break;
            }
            if (this.curr_tile==1){
                int value = dice.roll();
                System.out.print("[Roll-"+Dice.getTotal_rolls()+"]: "+this.name+" rolled "+value+" at Tile-1, ");
                if (value==6){
                    System.out.println("You are out of the Cage! You get a free roll.");
                    value = dice.roll();
                    System.out.print("[Roll-"+Dice.getTotal_rolls()+"]: "+this.name+" rolled "+value+" at Tile-1, ");
                    System.out.println("Landed on Tile "+(this.curr_tile+value)+".");
                    this.curr_tile+=value;
                    this.shake();
                }else{
                    System.out.println("OOPs You need 6 to Start");
                }
            }else{
                int value = dice.roll();
                System.out.print("[Roll-"+Dice.getTotal_rolls()+"]: "+this.name+" rolled "+value+" at Tile-"+this.curr_tile+", ");
                if (this.curr_tile+value>length) {
                    System.out.println("Landed on Tile " + this.curr_tile);
                }else if(this.curr_tile+value==length){
                    this.curr_tile = length;
                    throw new GameWinnerException("Landed on Tile " + length);
                }else{
                    this.curr_tile+=value;
                    System.out.println("Landed on Tile " + (this.curr_tile) + ".");
                    this.shake();
                }
            }
        }
    }
    public void shake(){
        System.out.println("Trying to Shake the Tile-"+this.curr_tile);
        if (track.get(this.curr_tile-1).getClass().getName().equals("Snake")){
            snake_bites++;
        }else if(track.get(this.curr_tile-1).getClass().getName().equals("Cricket")){
            cricket_bites++;
        }else if(track.get(this.curr_tile-1).getClass().getName().equals("Vulture")){
            vulture_bites++;
        }else if(track.get(this.curr_tile-1).getClass().getName().equals("Trampoline")){
            trampolines++;
        }
        try {
            track.get(this.curr_tile - 2).action();
        }catch (SnakeBiteException e) {
            System.out.println("Hiss...! I am a Snake, You go back "+(track.get(this.curr_tile-2).getMove()*-1)+" tiles!");
        }catch (CricketBiteException e) {
            System.out.println("Chirp...! I am a Cricket, You go back "+(track.get(this.curr_tile-2).getMove()*-1)+" tiles!");
        }catch (VultureBiteException e) {
            System.out.println("Yapping...! I am a Vulture, You go back "+(track.get(this.curr_tile-2).getMove()*-1)+" tiles!");
        }catch (TrampolineException e) {
            System.out.println("PingPong...! I am a Trampoline, You advance "+(track.get(this.curr_tile-2).getMove())+" tiles!");
        }
        int temp = track.get(this.curr_tile-2).getMove();
        this.curr_tile += temp;
        if (this.curr_tile<1){
            this.curr_tile=1;
        }else if(this.curr_tile>length){
            this.curr_tile -= temp;
        }
        System.out.println(this.name+" moved to Tile-"+this.curr_tile);
    }
    public int getSnake_bites(){
        return this.snake_bites;
    }
    public int getCricket_bites(){
        return this.cricket_bites;
    }
    public int getVulture_bites(){
        return this.vulture_bites;
    }
    public int getTrampolines(){
        return this.trampolines;
    }
    public String getName(){
        return this.name;
    }
}

abstract class Tile{
    private final int move;
    Tile(int move){
        this.move = move;
    }
    public abstract void action() throws SnakeBiteException,VultureBiteException,CricketBiteException,TrampolineException;
    public int getMove(){
        return this.move;
    }
}

class Snake extends Tile{
    private static int total_snakes;
    private final int move_forward;
    Snake(int move){
        super(move);
        move_forward = move;
        total_snakes++;
    }
    @Override
    public void action() throws SnakeBiteException{
        throw new SnakeBiteException("Hiss...! I am a Snake, You go back "+(this.move_forward*-1)+" tiles!");
    }
    public static int getTotal_snakes(){
        return Snake.total_snakes;
    }
}

class Cricket extends Tile{
    private static int total_crickets;
    private final int move_forward;
    Cricket(int move){
        super(move);
        move_forward = move;
        total_crickets++;
    }
    @Override
    public void action() throws CricketBiteException{
        throw new CricketBiteException("Chirp...! I am a Cricket, You go back "+(this.move_forward*-1)+" tiles!");
    }
    public static int getTotal_crickets(){
        return Cricket.total_crickets;
    }
}

class Vulture extends Tile{
    private static int total_vultures;
    private final int move_forward;
    Vulture(int move){
        super(move);
        move_forward = move;
        total_vultures++;
    }
    @Override
    public void action() throws VultureBiteException{
        throw new VultureBiteException("Yapping...! I am a Vulture, You go back "+(this.move_forward*-1)+" tiles!");
    }
    public static int getTotal_vultures(){
        return Vulture.total_vultures;
    }
}

class Trampoline extends Tile{
    private static int total_trampolines;
    private final int move_forward;
    Trampoline(int move){
        super(move);
        move_forward = move;
        total_trampolines++;
    }
    @Override
    public void action() throws TrampolineException{
        throw new TrampolineException("PingPong...! I am a Trampoline, You advance "+(this.move_forward)+" tiles!");
    }
    public static int getTotal_trampolines(){
        return Trampoline.total_trampolines;
    }
}

class White extends Tile{
    private static int total_whites;
    private final int move_forward;
    White(int move){
        super(move);
        move_forward = move;
        total_whites++;
    }
    @Override
    public void action(){
        System.out.println("I am a White Tile.");
    }
    public static int getTotal_whites(){
        return White.total_whites;
    }
}

class Dice{
    private final int sides;
    private static int total_rolls;
    Dice(int sides){
        this.sides = sides;
    }
    public int roll(){
        total_rolls++;
        Random rand = new Random();
        return (rand.nextInt(sides)+1);
    }
    public static int getTotal_rolls(){
        return Dice.total_rolls;
    }
}

class Game_layout{
    private final int total_tiles;
    private int snake_move;
    private int cricket_move;
    private int vulture_move;
    private int trampoline_move;
    private final int white_move = 0;
    private static ArrayList<Tile> track = new ArrayList<>();
    Game_layout(int length){
        this.total_tiles=length;
    }
    public void draw_map(){
        System.out.println("Setting up the race track...");
        Random rand = new Random();
        snake_move = -rand.nextInt(10)-1;
        cricket_move = -rand.nextInt(10)-1;
        vulture_move = -rand.nextInt(10)-1;
        trampoline_move = rand.nextInt(10)+1;
        for (int i=0;i<total_tiles-1;i++){
            int choose = rand.nextInt(5);
            if (choose==0){
                track.add(new Snake(snake_move));
            }else if(choose==1){
                track.add(new Cricket(cricket_move));
            }else if(choose==2){
                track.add(new Vulture(vulture_move));
            }else if(choose==3){
                track.add(new Trampoline(trampoline_move));
            }else{
                track.add(new White(white_move));
            }
        }
        System.out.println("Danger : There are "+Snake.getTotal_snakes()+", "+Cricket.getTotal_crickets()+", and "+Vulture.getTotal_vultures()+" numbers of Snakes, Cricket, and Vultures respectively on your track!");
        System.out.println("Danger : Eack Snake, Cricket, and Vulture can throw you back by "+(this.snake_move*-1)+", "+(this.cricket_move*-1)+" and "+(this.vulture_move*-1)+" number of Tiles respectively");
        System.out.println("Good News : There are "+Trampoline.getTotal_trampolines()+" number of Trampolines on your track!");
        System.out.println("Good News : Eack trampoline can help you advance by "+this.trampoline_move+" number of tiles");
    }
    public static ArrayList<Tile> getTrack(){
        return Game_layout.track;
    }
}

class SnakeBiteException extends Exception{
    SnakeBiteException(String message){
        super(message);
    }
}

class CricketBiteException extends Exception{
    CricketBiteException(String message){
        super(message);
    }
}

class VultureBiteException extends Exception{
    VultureBiteException(String message){
        super(message);
    }
}

class TrampolineException extends Exception{
    TrampolineException(String message){
        super(message);
    }
}

class GameWinnerException extends Exception{
    GameWinnerException(String message){
        super(message);
    }
}