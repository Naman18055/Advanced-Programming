import java.util.*;
public class Assignment2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Merchant> allmerchants = new ArrayList<>();
        ArrayList<Customer> allcustomers = new ArrayList<>();
        allmerchants.add(new Merchant("jack","100"));
        allmerchants.add(new Merchant("john","101"));
        allmerchants.add(new Merchant("james","102"));
        allmerchants.add(new Merchant("jeff","103"));
        allmerchants.add(new Merchant("joseph","104"));
        allcustomers.add(new Customer("ali","105"));
        allcustomers.add(new Customer("nobby","106"));
        allcustomers.add(new Customer("bruno","107"));
        allcustomers.add(new Customer("borat","108"));
        allcustomers.add(new Customer("aladeen","109"));
        int choice = 0;
        while (choice!=5) {
            System.out.println("Welcome to Mercury");
            System.out.println("1) Enter as Merchant");
            System.out.println("2) Enter as Customer");
            System.out.println("3) See user details");
            System.out.println("4) Company Account Balance");
            System.out.println("5) Exit");
            choice = input.nextInt();
            if (choice == 1) {
                for (int i=0;i<allmerchants.size();i++){
                    System.out.print(""+allmerchants.get(i).getid()+" ");
                    System.out.println(allmerchants.get(i).getname());
                }
                int merchantid = input.nextInt();
                for (int i=0;i<allmerchants.size();i++){
                    if (merchantid==allmerchants.get(i).getid()){
                        System.out.println("Welcome "+allmerchants.get(i).getname());
                        allmerchants.get(i).merchantmenu();
                        break;
                    }
                }
            } else if (choice == 2) {
                for (int i=0;i<allcustomers.size();i++){
                    System.out.print(""+allcustomers.get(i).getid()+" ");
                    System.out.println(allcustomers.get(i).getname());
                }
                int customerid = input.nextInt();
                for (int i=0;i<allcustomers.size();i++){
                    if (customerid==allcustomers.get(i).getid()){
                        System.out.println("Welcome "+allcustomers.get(i).getname());
                        allcustomers.get(i).customermenu();
                        break;
                    }
                }
            } else if (choice == 3) {
                System.out.println("All Customers : ");
                for (int i=0;i<allcustomers.size();i++){
                    System.out.println(""+allcustomers.get(i).getid()+") "+allcustomers.get(i).getname());
                }
                System.out.println("All Merchants : ");
                for (int i=0;i<allmerchants.size();i++) {
                    System.out.println("" + allmerchants.get(i).getid() + ") " + allmerchants.get(i).getname());
                }
                String option = input.next();
                int id = Integer.parseInt(input.next());
                if (option.equals("M")){
                    for (int i=0;i<allmerchants.size();i++){
                        if (allmerchants.get(i).getid()==id){
                            System.out.println(allmerchants.get(i).getname()+" "+Company.displayaddress(allmerchants.get(i))+" "+allmerchants.get(i).getContributed());
                            break;
                        }
                    }
                }else{
                    for (int i=0;i<allcustomers.size();i++){
                        if (allcustomers.get(i).getid()==id){
                            System.out.println(allcustomers.get(i).getname()+" "+Company.displayaddress(allcustomers.get(i))+" "+allcustomers.get(i).getOrders());
                            break;
                        }
                    }
                }
            } else if (choice == 4) {
                System.out.println("Company Account Balance : "+Company.getBalance());
            } else if (choice == 5) {
                System.exit(0);
            } else {
                System.out.println("Wrong Input");
            }
        }
    }
}

class Merchant implements details{
    Scanner input = new Scanner(System.in);
    private final String name;
    private final String address;
    private static int totalmerchants = 0;
    private final int id;
    private float contributed = 0;
    private int slots = 10;
    private ArrayList<Item> allitems = new ArrayList<>();
    private HashMap<String , Integer> allcategories = new HashMap<>();
    private float account = 0;
    Merchant(String name , String address){
        this.name = name;
        this.address = address;
        this.totalmerchants++;
        this.id = totalmerchants;
    }
    @Override
    public String getAddress(){
        return this.address;
    }
    void setAccount(float money){
        this.account=money;
    }
    void setContributed(float money){
        this.contributed+=money;
    }
    float getContributed(){
        return this.contributed;
    }
    float getAccount(){
        return this.account;
    }
    String getname(){
        return this.name;
    }
    Integer getid(){
        return this.id;
    }
    void merchantmenu(){
        System.out.println("Merchant Menu");
        System.out.println("1) Add Item");
        System.out.println("2) Edit Item");
        System.out.println("3) Search by Category");
        System.out.println("4) Add Offer");
        System.out.println("5) Rewards Won");
        System.out.println("6) Exit");
        int choice = input.nextInt();
        if (choice==1){
            this.additem();
        }else if(choice==2){
            this.edititem();
        }else if(choice==3){
            Company.search(this);
        }else if(choice==4){
            this.addoffer();
        }else if(choice==5){
            this.rewards();
        }
    }
    void additem(){
        if (this.allitems.size()==this.slots){
            System.out.println("Cannot add more Items - Slot Limit Reached");
        }else {
            System.out.print("Enter Item Name : ");
            String itemname = input.next();
            System.out.print("Enter Item Price : ");
            int itemprice = input.nextInt();
            System.out.print("Enter Item Quantity : ");
            int itemquantity = input.nextInt();
            System.out.print("Enter Item Category : ");
            String itemcategory = input.next();
            Item item = new Item(itemcategory);
            item.setname(itemname);
            item.setprice(itemprice);
            item.setQuantity(itemquantity);
            item.setMerchantname(this);
            this.allitems.add(item);
            Company.additem(item);
            Company.addcategory(itemcategory);
            //Company.additemid(item.getId(),this.name);
            if (this.allcategories.get(itemcategory) == null) {
                this.allcategories.put(itemcategory, 1);
            } else {
                this.allcategories.put(itemcategory, this.allcategories.get(itemcategory) + 1);
            }
        }
        this.merchantmenu();
    }
    void edititem(){
        System.out.println("Choose Item by Code - ");
        for (int i=0;i<this.allitems.size();i++){
            Item temp = this.allitems.get(i);
            temp.itemdisplay();
        }
        int code = input.nextInt();
        Item temp = this.allitems.get(code-1);
        System.out.println("Enter edit details - ");
        System.out.print("Enter new Price : ");
        int newprice = input.nextInt();
        System.out.print("Enter quantity : ");
        int newquantity = input.nextInt();
        temp.setprice(newprice);
        temp.setQuantity(newquantity);
        temp.itemdisplay();
        this.merchantmenu();
    }
    @Override
    public void search(){
        System.out.println("Choose a Category - ");
        int j=0;
        for (String i : this.allcategories.keySet()){
            System.out.println((j+1)+" "+i);
            j++;
        }
        int code = input.nextInt();
        j=0;
        String categorychosen="";
        for (String i : this.allcategories.keySet()){
            if (code==j+1){
                categorychosen = i;
            }
            j++;
        }
        for (int i=0;i<this.allitems.size();i++){
            if (this.allitems.get(i).getCategory().equals(categorychosen)){
                this.allitems.get(i).itemdisplay();
            }
        }
        this.merchantmenu();
    }
    void addoffer(){
        System.out.println("Choose item by Code");
        for (int i=0;i<this.allitems.size();i++){
            Item temp = this.allitems.get(i);
            temp.itemdisplay();
        }
        int code = input.nextInt();
        Item item = new Item("");
        for (int i=0;i<allitems.size();i++){
            if (allitems.get(i).getId()==code){
                item = allitems.get(i);
                break;
            }
        }
        System.out.println("Choose Offer - ");
        System.out.println("1) buy 1 get 1");
        System.out.println("2) 25% off");
        int offer = input.nextInt();
        if (offer==1){
            item.setOffer("buy 1 get 1");
        }else if(offer==2){
            item.setOffer("25% off");
        }
        item.itemdisplay();
        this.merchantmenu();
    }
    void rewards(){
        System.out.println("Contribution to Company : "+this.contributed);
        System.out.println("Total Slots Awarded : "+(this.slots-10));
        this.merchantmenu();
    }
}

class Customer implements details{
    Scanner input = new Scanner(System.in);
    private final String name;
    private final String address;
    private static int totalcustomers;
    private int id;
    private ArrayList<int[]> cart = new ArrayList<>();
    private ArrayList<String> latestorders = new ArrayList<>();
    private float remainingbalance = 100;
    private float rewardsaccount=0;
    private int totalpurchases=0;
    Customer(String name , String address){
        this.name = name;
        this.address = address;
        Customer.totalcustomers++;
        this.id = totalcustomers;
    }
    String getname(){
        return this.name;
    }
    @Override
    public String getAddress(){
        return this.address;
    }
    public int getOrders(){
        return latestorders.size();
    }
    Integer getid(){
        return this.id;
    }
    void customermenu(){
        System.out.println("Customer Menu");
        System.out.println("1) Search Item");
        System.out.println("2) Checkout Cart");
        System.out.println("3) Reward Won");
        System.out.println("4) Print latest orders");
        System.out.println("5) Exit");
        int choice = input.nextInt();
        if (choice==1){
            Company.search(this);
        }else if(choice==2){
            this.checkoutcart();
        }else if(choice==3){
            this.rewardswon();
        }else if(choice==4){
            this.listrecentorders();
        }
    }
    @Override
    public void search(){
        System.out.println("Choose a Category - ");
        HashMap<String , Integer> temp = Company.getcategories();
        int j = 0;
        for (String i : temp.keySet()){
            System.out.println((j+1)+") "+i);
            j++;
        }
        int code = input.nextInt();
        j=0;
        String categorychosen="";
        for (String i : temp.keySet()){
            if (j+1==code){
                categorychosen = i;
                break;
            }
            j++;
        }
        ArrayList<Item> item = Company.getallitems();
        for (int i=0;i<item.size();i++){
            if (item.get(i).getCategory().equals(categorychosen)){
                item.get(i).itemdisplay();
            }
        }
        System.out.println("Enter Item Code - ");
        int itemcode = input.nextInt();
        System.out.println("Enter Item Quantity - ");
        int itemquantity = input.nextInt();
        Item itemtobeadded = new Item("");
        for (int i=0;i<item.size();i++){
            if (item.get(i).getId()==itemcode){
                itemtobeadded = item.get(i);
                break;
            }
        }
        if (itemtobeadded.getOffer()!=null) {
            if (itemtobeadded.getOffer().equals("25% off")) {
                itemtobeadded.setprice(itemtobeadded.getPrice() * (float) 0.75);
            }
        }
        System.out.println("Choose method of transaction - ");
        System.out.println("1) Buy Item");
        System.out.println("2) Add Item to cart");
        System.out.println("3) Exit");
        int option = input.nextInt();
        if (option==1){
            if (itemtobeadded.getPrice()*itemquantity*1.005<=this.remainingbalance && itemtobeadded.getQuantity()>=itemquantity) {
                System.out.println("Item successfully bought");
                this.remainingbalance -= (itemtobeadded.getPrice() * itemquantity * 1.005);
                itemtobeadded.getMerchantname().setAccount(itemtobeadded.getMerchantname().getAccount()+(itemtobeadded.getPrice()*itemquantity*(float)0.995));
                Company.setBalance(Company.getBalance()+(itemtobeadded.getPrice()*itemquantity*(float)0.01));
                itemtobeadded.getMerchantname().setContributed((itemtobeadded.getPrice()*itemquantity*(float)0.005));
                if (itemtobeadded.getOffer()!=null) {
                    if (itemtobeadded.getOffer().equals("buy 1 get 1")) {
                        itemtobeadded.setQuantity(itemtobeadded.getQuantity() - itemquantity * 2);
                    }
                }else{
                    itemtobeadded.setQuantity(itemtobeadded.getQuantity() - itemquantity);
                }
                this.latestorders.add("Bought item " + itemtobeadded.getName() + " quantity : " + itemquantity + " for Rs " + (itemtobeadded.getPrice() * itemquantity) + " from Merchant " + itemtobeadded.getMerchantname().getname());
            }else if(itemtobeadded.getQuantity()<itemquantity){
                System.out.println("Out of Stock");
            }else{
                System.out.println("Out of Money");
            }
        }else if(option==2){
            System.out.println("Successfully added to cart");
            int[] temp2 = new int[2];
            temp2[0] = itemcode;
            temp2[1] = itemquantity;
            this.cart.add(temp2);
        }
        this.customermenu();
    }
    void checkoutcart(){
        int code = this.cart.get(0)[0];
        Item itemtobechecked = new Item("");
        for (int i=0;i<Company.getallitems().size();i++){
            if (Company.getallitems().get(i).getId()==code){
                itemtobechecked = Company.getallitems().get(i);
                System.out.println("Item in Cart - ");
                itemtobechecked.itemdisplay();
            }
        }
        System.out.println("Do you want to checkout?");
        System.out.println("1) YES");
        System.out.println("2) NO");
        int choice = input.nextInt();
        if (choice==1){
            if (itemtobechecked.getPrice()*this.cart.get(0)[1]*1.005<=this.remainingbalance && itemtobechecked.getQuantity()>=this.cart.get(0)[1]) {
                System.out.println("Item successfully bought");
                this.totalpurchases++;
                if (totalpurchases%5==0){
                    this.rewardsaccount+=10;
                }
                itemtobechecked.getMerchantname().setAccount(itemtobechecked.getMerchantname().getAccount()+(itemtobechecked.getPrice()*this.cart.get(0)[1]*(float)0.995));
                Company.setBalance(Company.getBalance()+(itemtobechecked.getPrice()*this.cart.get(0)[1]*(float)0.005));
                if (itemtobechecked.getOffer()!=null) {
                    if (itemtobechecked.getOffer().equals("buy 1 get 1")) {
                        itemtobechecked.setQuantity(itemtobechecked.getQuantity() - this.cart.get(0)[1] * 2);
                    }
                }else {
                    itemtobechecked.setQuantity(itemtobechecked.getQuantity() - this.cart.get(0)[1]);
                }
                itemtobechecked.getMerchantname().setContributed((itemtobechecked.getPrice()*this.cart.get(0)[1]*(float)0.005));
                this.cart.remove(0);
                this.remainingbalance -= (itemtobechecked.getPrice() * this.cart.get(0)[1] * 1.005);
                this.latestorders.add("Bought item " + itemtobechecked.getName() + " quantity : " + this.cart.get(0)[1] + " for Rs " + (itemtobechecked.getPrice() * this.cart.get(0)[1]) + " from Merchant " + itemtobechecked.getMerchantname().getname());
            }else if(itemtobechecked.getQuantity()<this.cart.get(0)[1]){
                System.out.println("Out of Stock");
            }else{
                System.out.println("Out of Money");
            }
        }
        this.customermenu();
    }
    void rewardswon(){
        System.out.print("Total Rewards Won : ");
        System.out.println(this.totalpurchases/5);
        this.customermenu();
    }
    void listrecentorders(){
        System.out.println("Recent Orders - ");
        for (int i=this.latestorders.size()-1;i>-1;i--){
            System.out.println(latestorders.get(i));
        }
        this.customermenu();
    }
}

class Item{
    private static int totalitems;
    private final String category;
    private int quantity;
    private String name;
    private float price;
    private int id;
    private String offer = null;
    private Merchant merchantname;
    Item(String category) {
        this.category = category;
        totalitems++;
        this.id = totalitems;
    }
    void setprice(float price){
        this.price=price;
    }
    void setname(String name){
        this.name = name;
    }
    void setQuantity(int quantity){
        this.quantity = quantity;
    }
    void setOffer(String offer){
        this.offer = offer;
    }
    void setMerchantname(Merchant merchant){
        this.merchantname=merchant;
    }
    void itemdisplay(){
        System.out.println(""+this.getId()+" "+this.getName()+" "+this.getPrice()+" "+this.getQuantity()+" "+this.getOffer()+" "+this.getCategory());
    }
    float getPrice(){
        return this.price;
    }
    int getQuantity(){
        return this.quantity;
    }
    int getId(){
        return this.id;
    }
    String getName(){
        return this.name;
    }
    String getOffer(){
        return this.offer;
    }
    String getCategory(){
        return this.category;
    }
    Merchant getMerchantname(){
        return this.merchantname;
    }

}

class Company{
    private static float account=0;
    private static ArrayList<Item> allitems = new ArrayList<>();
    private static HashMap<String , Integer> allcategories = new HashMap<>();
    private static HashMap<Integer , String> itemid = new HashMap<>();
    static void setBalance(float money){
        Company.account=money;
    }
    static float getBalance(){
        return Company.account;
    }
    static void additem(Item item){
        Company.allitems.add(item);
    }
    static void addcategory(String s){
        if (Company.allcategories.get(s)==null){
            Company.allcategories.put(s,1);
        }else{
            Company.allcategories.put(s,Company.allcategories.get(s)+1);
        }
    }
    static void additemid(int id , String s){
        Company.itemid.put(id,s);
    }
    static HashMap<String,Integer> getcategories(){
        return Company.allcategories;
    }
    static HashMap<Integer,String> getitemid(){
        return Company.itemid;
    }
    static ArrayList<Item> getallitems(){
        return Company.allitems;
    }
    static void search(details searcher){
        searcher.search();
    }
    static String displayaddress(details address){
        return address.getAddress();
    }
}

interface details{
    String getAddress();
    void search();
}