import java.util.*;
import java.lang.*;

public class Assignment4 {
    public static void main(String[] args) {
        Game_Layout.draw_map();
        Game_Layout.setMonsters_allocated();
        Start new_game = new Start();
        new_game.menu();
    }
}

class Start{
    Scanner input = new Scanner(System.in);
    private static ArrayList<Hero> users = new ArrayList<>();
    public void menu(){
        System.out.println("Welcome to ArchLegends");
        System.out.println("Choose your option");
        System.out.println("1) New User");
        System.out.println("2) Existing User");
        System.out.println("3) Exit");
        int option = input.nextInt();
        if (option==1){
            this.create_user();
        }else if(option==2){
            this.existing_user();
        }
    }
    public void create_user(){
        System.out.println("Enter Username");
        String name = input.next();
        System.out.println("Choose Hero");
        System.out.println("1) Warrior");
        System.out.println("2) Thief");
        System.out.println("3) Mage");
        System.out.println("4) Healer");
        int option = input.nextInt();
        Hero user = new Warrior(10,2,"");
        if (option==1){
            user = new Warrior(10,3,name);
            users.add(user);
        }else if(option==2){
            user = new Thief(5,5,name);
            users.add(user);
        }else if(option==3){
            user = new Mage(6,4,name);
            users.add(user);
        }else{
            user = new Healer(4, 8, name);
            users.add(user);
        }
        System.out.println("User Creation Done. Username : "+name+". Hero : "+user.getClass().getName()+". Login to play the game. Exiting");
        this.menu();
    }
    public void existing_user(){
        System.out.println("Enter Username");
        String name = input.next();
        Hero user = new Warrior(0,0,"a");
        int flag=0;
        for (int i=0;i<users.size();i++){
            if (users.get(i).getName().equals(name)){
                user = users.get(i);
                System.out.println("User Found... logging in");
                System.out.println("Welcome "+user.getName());
                flag=1;
                break;
            }
        }
        if (flag==0){
            System.out.println("No User Found");
            this.menu();
        }else {
            this.start_game(user);
        }
    }
    public void start_game(Hero user){
        System.out.println("You are at the starting location. Choose path : ");
        System.out.println("1) Go to location 1");
        System.out.println("2) Go to location 2");
        System.out.println("3) Go to location 3");
        System.out.println("4) Use Hint");
        System.out.println("Enter -1 to exit");
        int choice = input.nextInt();
        if (choice == 4){
            System.out.println("Choose location : "+Game_Layout.calc_best_location(0));
            System.out.println("1) Go to location 1");
            System.out.println("2) Go to location 2");
            System.out.println("3) Go to location 3");
            System.out.println("Enter -1 to exit");
            choice = input.nextInt();
        }
        Monsters m = new Goblins(1,100);
        int level = -1;
        if (choice == 1) {
            level = Game_Layout.getMonsters_allocated()[1];
        }else if(choice==2){
            level = Game_Layout.getMonsters_allocated()[2];
        }else if(choice==3){
            level = Game_Layout.getMonsters_allocated()[3];
        }else{
            this.menu();
        }
        if (level==1){
            m = new Goblins(1,100);
        }else if(level==2){
            m = new Zombies(2,150);
        }else if(level==3){
            m = new Fiends(3,200);
        }else{
            m = new Lionfang(4,250);
        }
        int prev_location=0;
        System.out.println("Moving to location "+choice);
        System.out.println("Fight started. Your fighting a level "+level+" Monster.");
        prev_location = choice;
        int flag=0;
        user.setXp(0);
        String if_sidekick = "no";
        if (fight(user,m,Sidekick.getAll_sidekicks(),if_sidekick)){
            this.menu();
        }else{
            while (choice!=28 && flag==0){
                if_sidekick = "no";
                System.out.println("If you would like to buy a sidekick, type yes. Else type no to upgrade level. ");
                String sidekick_choice = input.next();
                if (sidekick_choice.equals("no")){
                    int initial_level = user.getLevel();
                    System.out.println("Your level is : "+initial_level);
                }else{
                    System.out.println("Your current XP is : "+user.getXp());
                    System.out.println("If you want to buy a minion , press 1");
                    System.out.println("If you want to buy a knight , press 2");
                    int sidekick_option = input.nextInt();
                    System.out.println("XP to spend : ");
                    float xp_to_buy = input.nextFloat();
                    int temp10 = (int)(xp_to_buy);
                    Sidekick sidekick;
                    if (sidekick_option==1){
                        sidekick = new Minion(1+((xp_to_buy-5)/2));
                        user.setXp(-temp10);
                        Sidekick.add_sidekick(sidekick);
                        System.out.println("You bought a sidekick Minion");

                    }else{
                        sidekick = new Knight(2+((xp_to_buy-8)/2));
                        Sidekick.add_sidekick(sidekick);
                        user.setXp(-temp10);
                        System.out.println("You bought a sidekick Knight");
                        sidekick.setAbilitiy_used(true);
                    }
                    System.out.println("Xp of sidekick : "+sidekick.getXp());
                    System.out.println("Attack of Sidekick is : "+sidekick.getAttack());
                }
                System.out.println("You are at location "+choice);
                for (int i=0;i<Game_Layout.getMap()[choice].size();i++){
                    System.out.println((i+1)+") Go to location "+Game_Layout.getMap()[choice].get(i));
                }
                System.out.println("4) Go Back");
                System.out.println("5) Use Hint");
                int option = input.nextInt();
                if (option==5){
                    System.out.println("Choose location : "+Game_Layout.calc_best_location(choice));
                    for (int i=0;i<Game_Layout.getMap()[choice].size();i++){
                        System.out.println((i+1)+") Go to location "+Game_Layout.getMap()[choice].get(i));
                    }
                    System.out.println("4) Go Back");
                    option = input.nextInt();
                }
                for (int i=0;i<Game_Layout.getMap()[choice].size();i++){
                    if (option-1==i){
                        prev_location=choice;
                        choice = Game_Layout.getMap()[choice].get(i);
                        System.out.println("Moving to location "+Game_Layout.getMap()[prev_location].get(i));
                        level = Game_Layout.getMonsters_allocated()[Game_Layout.getMap()[prev_location].get(i)];
                        System.out.println("Fight started. You are fighting a level "+level+" Monster");
                        if (Sidekick.getAll_sidekicks().size()>0) {
                            System.out.println("Type yes if you wish to use a sidekick, else type no");
                            if_sidekick = input.next();
                        }
                        if (level==1){
                            m = new Goblins(1,100);
                        }else if(level==2){
                            m = new Zombies(2,150);
                        }else if(level==3){
                            m = new Fiends(3,200);
                        }else{
                            m = new Lionfang(4,250);
                        }
                        if (fight(user,m,Sidekick.getAll_sidekicks(),if_sidekick)){
                            flag=1;
                        }
                        break;
                    }
                }
                if (option==4){
                    System.out.println("Moving to location "+prev_location);
                    level = Game_Layout.getMonsters_allocated()[prev_location];
                    System.out.println("Fight started. You are fighting a level "+level+" Monster");
                    if (level==1){
                        m = new Goblins(1,100);
                    }else if(level==2){
                        m = new Zombies(2,150);
                    }else if(level==3){
                        m = new Fiends(3,200);
                    }else{
                        System.out.println("You are fighting Lionfang");
                        m = new Lionfang(4,250);
                    }
                    if (fight(user,m,Sidekick.getAll_sidekicks(),if_sidekick)){
                        flag=1;
                    }
                }
            }
            if (flag==1){
                user.setXp(0);
                System.out.println("You lost the game");
                this.menu();
            }
        }
    }
    public boolean fight(Hero user, Monsters enemy, ArrayList<Sidekick> all_sidekick, String sidekick_choice){
        int turn = 0;
        int remaining = 4;
        int flag=0;
        int extra_defence=0;
        if (all_sidekick.size()>0){
            if (all_sidekick.get(0).getClass().getName().equals("Knight") && (enemy.getClass().getName().equals("Zombies"))){
                extra_defence=5;
            }else{
                extra_defence=0;
            }
        }
        String cloning_choice = "f";
        Sidekick clone1,clone2,clone3;
        clone1 = new Minion(2);
        clone2 = new Minion(2);
        clone3 = new Minion(2);
        if (sidekick_choice.equals("yes")){
            System.out.println("You have a sidekick "+all_sidekick.get(0).getClass().getName()+" with you. Attack of sidekick is "+all_sidekick.get(0).getAttack());
            if (!all_sidekick.get(0).getAbility_used()){
                System.out.println("Press c to use cloning ability. Else press f to move to fight.");
                cloning_choice = input.next();
                if (cloning_choice.equals("c")){
                    clone1 = all_sidekick.get(0).clone();
                    clone2 = all_sidekick.get(0).clone();
                    clone3 = all_sidekick.get(0).clone();
                    System.out.println("Cloning done");
                    all_sidekick.get(0).setAbilitiy_used(true);
                }
            }
        }
        while (user.getHp()!=0 && enemy.getHp()!=0){
            if (turn==0){
                System.out.println("Choose Move : ");
                System.out.println("1) Attack");
                System.out.println("2) Defense");
                if (remaining==0){
                    System.out.println("3) Use Special Power");
                }else{
                    if (user.getPower_activated()==false){
                        remaining-=1;
                    }
                }
                int choice = input.nextInt();
                if (choice==1){
                    user.special_power(enemy);
                    float temp = user.attack();
                    System.out.println("You Choose to Attack");
                    System.out.println("You attacked and inflicted "+temp+" damage to the monster.");
                    if (sidekick_choice.equals("yes")){
                        System.out.println("Sidekick attacked and inflicted "+all_sidekick.get(0).getAttack()+" damage to the monster");
                        temp+=all_sidekick.get(0).getAttack();
                        if (cloning_choice.equals("c")){
                            System.out.println("Sidekick attacked and inflicted "+clone1.getAttack()+" damage to the monster");
                            temp+=all_sidekick.get(0).getAttack();
                            System.out.println("Sidekick attacked and inflicted "+clone2.getAttack()+" damage to the monster");
                            temp+=all_sidekick.get(0).getAttack();
                            System.out.println("Sidekick attacked and inflicted "+clone3.getAttack()+" damage to the monster");
                            temp+=all_sidekick.get(0).getAttack();
                            System.out.println("Sidekick's HP : "+clone1.getHp());
                            System.out.println("Sidekick's HP : "+clone2.getHp());
                            System.out.println("Sidekick's HP : "+clone3.getHp());
                        }
                        System.out.println("Sidekick's HP : "+all_sidekick.get(0).getHp());
                    }
                    if (temp>enemy.getHp()){
                        temp=enemy.getHp();
                    }
                    enemy.setHp(temp);
                    System.out.println("Your Hp : "+user.getHp()+" Monster Hp : "+enemy.getHp());
                    turn=1;
                }else if(choice==2){
                    user.special_power(enemy);
                    System.out.println("You choose to Defend");
                    System.out.println("Monster attack reduced by "+user.defense());
                    System.out.println("Your Hp : "+user.getHp()+" Monster Hp : "+enemy.getHp());
                    flag=1;
                    turn=1;
                }else{
                    System.out.println("Special Power Activated");
                    turn = user.use_special_power(enemy);
                    remaining=4;
                }
            }else{
                System.out.println("Monster Attack");
                int flag2=0;
                if (enemy.getClass().getName().equals("Lionfang")){
                    Random num = new Random();
                    int x = num.nextInt(10)+60;
                    if (x==69){
                        flag2=1;
                        System.out.println("Special Attack of Lionfang");
                        user.setHp(user.getHp()/2);
                        if (sidekick_choice.equals("yes")) {
                            float shp = all_sidekick.get(0).getHp();
                            shp = shp / 2;
                            all_sidekick.get(0).setHp(shp);
                            if (cloning_choice.equals("c")) {
                                clone1.setHp(shp);
                                clone2.setHp(shp);
                                clone3.setHp(shp);
                            }
                        }
                        if (flag==1){
                            user.setHp(-user.defence);
                        }
                        System.out.println("Your Hp : "+user.getHp()+" Monster Hp : "+enemy.getHp());
                        if (sidekick_choice.equals("yes")) {
                            System.out.println("Sidekick's HP : " + all_sidekick.get(0).getHp());
                            if (cloning_choice.equals("c")) {
                                System.out.println("Sidekick's HP : " + clone1.getHp());
                                System.out.println("Sidekick's HP : " + clone2.getHp());
                                System.out.println("Sidekick's HP : " + clone3.getHp());
                            }
                        }
                    }
                }
                if (flag2==0) {
                    if (flag == 1) {
                        int temp = enemy.attack() - extra_defence;
                        System.out.println(temp);
                        if (temp < user.getHp()) {
                            int temp2;
                            if (temp - user.defence > 0) {
                                temp2 = temp - user.defence;
                            } else {
                                temp2 = 0;
                            }
                            user.setHp(temp2);
                            System.out.println("The monster attacked and inflicted " + (temp2) + " damage to you");
                            System.out.println("Your Hp : " + user.getHp() + " Monster Hp : " + enemy.getHp());
                        } else {
                            float temp2 = user.getHp();
                            user.setHp(user.getHp());
                            System.out.println("The monster attacked and inflicted " + temp2 + " damage to you");
                            System.out.println("Your Hp : " + user.getHp() + " Monster Hp : " + enemy.getHp());
                        }
                        float temp2;
                        if (temp - user.defence > 0) {
                            temp2 = temp - user.defence;
                        } else {
                            temp2 = 0;
                        }
                        if (sidekick_choice.equals("yes")) {
                            float temp3 = (float)(temp2*1.5);
                            all_sidekick.get(0).setHp(temp3);
                            System.out.println("Sidekick's HP : " + all_sidekick.get(0).getHp());
                            if (cloning_choice.equals("c")) {
                                clone1.setHp(temp3);
                                clone2.setHp(temp3);
                                clone3.setHp(temp3);
                                System.out.println("Sidekick's HP : " + clone1.getHp());
                                System.out.println("Sidekick's HP : " + clone2.getHp());
                                System.out.println("Sidekick's HP : " + clone3.getHp());
                            }
                        }
                        if (all_sidekick.size()>0) {
                            if (all_sidekick.get(0).getHp() <= 0) {
                                sidekick_choice = "no";
                                cloning_choice = "f";
                                System.out.println("SIDEKICK IS DEAD.");
                                all_sidekick.remove(0);
                            }
                        }
                    } else {
                        int temp = enemy.attack();
                        //System.out.println(temp);
                        if (temp > user.getHp()) {
                            float temp2 = user.getHp();
                            user.setHp(user.getHp());
                            System.out.println("The monster attacked and inflicted " + temp2 + " damage to you");
                        } else {
                            user.setHp(temp);
                            System.out.println("The monster attacked and inflicted " + temp + " damage to you");
                        }
                        System.out.println("Your Hp : " + user.getHp() + " Monster Hp : " + enemy.getHp());
                        float temp2 = (float)(temp*1.5);
                        if (temp2>clone1.getHp()){
                            temp2 = clone1.getHp();
                        }
                        if (sidekick_choice.equals("yes")) {
                            all_sidekick.get(0).setHp(temp2);
                            System.out.println("Sidekick's HP : " + all_sidekick.get(0).getHp());
                            if (cloning_choice.equals("c")) {
                                clone1.setHp(temp2);
                                clone2.setHp(temp2);
                                clone3.setHp(temp2);
                                System.out.println("Sidekick's HP : " + clone1.getHp());
                                System.out.println("Sidekick's HP : " + clone2.getHp());
                                System.out.println("Sidekick's HP : " + clone3.getHp());
                            }
                        }
                        if (all_sidekick.size()>0) {
                            if (all_sidekick.get(0).getHp() <= 0) {
                                sidekick_choice = "no";
                                cloning_choice = "f";
                                System.out.println("SIDEKICK IS DEAD");
                                all_sidekick.remove(0);
                            }
                        }
                    }
                    flag = 0;
                    turn = 0;
                }
            }
        }
        if (user.getHp()==0){
            System.out.println("Game Over.");
            return true;
        }else{
            System.out.println("Monster Killed");
            System.out.println((20*enemy.getLevel())+" XP awarded");
            user.setXp(20*enemy.getLevel());
            System.out.println("User XP : "+user.getXp());
            if (sidekick_choice.equals("yes")) {
                all_sidekick.get(0).setXp((2*enemy.getLevel()));
                if (cloning_choice.equals("c")){
                    clone1.setXp(2*enemy.getLevel());
                    clone2.setXp(2*enemy.getLevel());
                    clone3.setXp(2*enemy.getLevel());
                    System.out.println("SideKick XP : " + all_sidekick.get(0).getXp());
                    System.out.println("SideKick XP : " + all_sidekick.get(0).getXp());
                    System.out.println("SideKick XP : " + all_sidekick.get(0).getXp());
                }
                System.out.println("SideKick XP : " + all_sidekick.get(0).getXp());
            }
            System.out.println("Fight Won. Proceed to the next location.");
            return false;
        }
    }
}

abstract class Hero{
    protected int level=1;
    protected int xp=0;
    protected float initial_hp=100;
    protected float hp = initial_hp;
    protected int attack;
    protected int defence;
    protected final String name;
    protected boolean power_activated = false;
    Hero(int attack , int defence , String name){
        this.attack=attack;
        this.defence=defence;
        this.name=name;
    }
    public void setAttack(int x){
        this.attack+=x;
    }
    public void setDefence(int x){
        this.defence+=x;
    }
    public int attack(){
        return this.attack+this.level-1;
    }
    public int defense(){
        return this.defence+this.level-1;
    }
    public boolean getPower_activated(){
        return  power_activated;
    }
    public abstract void special_power(Monsters m);
    public abstract int use_special_power(Monsters m);
    public void setXp(int xp) {
        this.xp += xp;
        if (this.xp>=120){
            this.level=4;
            this.initial_hp=250;
        }else if(this.xp>=60){
            this.level=3;
            this.initial_hp=200;
        }else if(this.xp>=20){
            this.level=2;
            this.initial_hp=150;
        }
        this.hp = this.initial_hp;
    }
    public String getName(){
        return this.name;
    }
    public float getHp(){
        return this.hp;
    }
    public int getXp(){ return this.xp; }
    public void setHp(float hp){
        this.hp-=hp;
    }
    protected void setPower_activated(boolean x){
        this.power_activated=x;
    }
    public int getLevel(){
        return this.level;
    }
}
class Warrior extends Hero {
    private int special_moves=-1;
    Warrior(int attack , int defense , String name) {
        super(attack, defense, name);
    }
    @Override
    public void special_power(Monsters m) {
        if (this.getPower_activated() && this.special_moves==-1){
            this.special_moves=0;
        }
        if (this.special_moves!=-1){
            if (this.special_moves==0){
                this.setAttack(5);
                this.setDefence(5);
            }
            special_moves+=1;
            if (this.special_moves==5){
                this.setAttack(-5);
                this.setDefence(-5);
                this.special_moves=-1;
                this.setPower_activated(false);
            }

        }
    }
    @Override
    public int use_special_power(Monsters m){
        this.setPower_activated(true);
        this.special_power(m);
        return 0;
    }
}
class Mage extends Hero {
    private int special_moves=-1;
    Mage(int attack ,int defense ,String name){
        super(attack ,defense,name);
    }
    @Override
    public void special_power(Monsters m){
        if (this.getPower_activated() && this.special_moves==-1){
            this.special_moves=0;
        }
        if (this.special_moves!=-1){
            this.special_moves+=1;
            m.setHp((m.getHp()*5)/100);
            if (this.special_moves==5){
                this.special_moves=-1;
                this.setPower_activated(false);
            }
        }
    }
    @Override
    public int use_special_power(Monsters m){
        this.setPower_activated(true);
        this.special_power(m);
        return 0;
    }
}
class Thief extends Hero {
    Thief(int attack , int defense ,String name){
        super(attack , defense, name);
    }
    @Override
    public void special_power(Monsters m){
        //Lol No Use :)
    }
    @Override
    public int use_special_power(Monsters m){
        System.out.println("Performing Special Attack");
        float temp = (m.getHp()*30)/100;
        m.setHp(temp);
        System.out.println("You have stolen "+temp+" HP from the monster");
        this.setHp(-temp);
        return 1;
    }

}
class Healer extends Hero {
    private int special_moves=-1;
    Healer(int attack , int defense , String name){
        super(attack , defense, name);
    }
    @Override
    public void special_power(Monsters m){
        if (this.getPower_activated() && this.special_moves==-1){
            this.special_moves=0;
        }
        if (this.special_moves!=-1){
            this.special_moves+=1;
            this.setHp((-this.getHp()*5)/100);
            if (this.special_moves==5){
                this.special_moves=-1;
                this.setPower_activated(false);
            }
        }
    }
    @Override
    public int use_special_power(Monsters m){
        this.setPower_activated(true);
        this.special_power(m);
        return 0;
    }
}


class Monsters{
    protected final int level;
    protected int initial_hp;
    private float hp;
    Monsters(int level, int hp){
        this.level = level;
        this.initial_hp = hp;
        this.hp = hp;
    }
    public void setHp(float hp){
        this.hp-=hp;
    }
    public float getHp(){
        return this.hp;
    }
    public int attack(){
        Random num = new Random();
        double prob = 2;
        while (prob<=-1 || prob>=1){
            prob = num.nextGaussian();
        }
        prob+=1;
        return (int)((prob*this.hp)/8)+1;
    }
    public int getLevel(){
        return this.level;
    }
}
class Goblins extends Monsters{
    Goblins(int level, int hp){
        super(level,hp);
    }
}
class Zombies extends Monsters{
    Zombies(int level, int hp){
        super(level,hp);
    }
}
class Fiends extends Monsters{
    Fiends(int level, int hp){
        super(level,hp);
    }
}
class Lionfang extends Monsters{
    Lionfang(int level, int hp){
        super(level,hp);
    }
}


class Game_Layout{
    private static ArrayList[] map = new ArrayList[29];
    private static int[] monsters_allocated = new int[29];
    //private static int[] best_path = new int[29];
    public static void draw_map(){
        for (int i=0;i<29;i++){
            Game_Layout.map[i]=new ArrayList<Integer>();
        }
        int node = 1;
        Game_Layout.map[0].add(node++);
        Game_Layout.map[0].add(node++);
        Game_Layout.map[0].add(node++);
        for (int i=1;i<4;i++){
            Game_Layout.map[i].add(node++);
            Game_Layout.map[i].add(node++);
            if (i!=3 && i%2==1) {
                Game_Layout.map[i].add(i + 1);
            }else if(i!=3){
                Game_Layout.map[i].add(i - 1);
            }else{
                Game_Layout.map[i].add(node++);
            }
        }
        for (int i=4;i<8;i++){
            Game_Layout.map[i].add(node++);
            Game_Layout.map[i].add(node++);
            if (i%2==0) {
                Game_Layout.map[i].add(i + 1);
            }else{
                Game_Layout.map[i].add(i - 1);
            }
        }
        for (int i=8;i<28;i++){
            if (i<11) {
                Game_Layout.map[i].add(node++);
                Game_Layout.map[i].add(node++);
                Game_Layout.map[i].add(node++);
            }else{
                Game_Layout.map[i].add(28);
            }
        }
    }
    public static void setMonsters_allocated(){
        Random num = new Random();
        for (int i=1;i<28;i++){
            monsters_allocated[i]=num.nextInt(3)+1;
        }
        monsters_allocated[28]=4;
    }
    public static int[] getMonsters_allocated(){
        return monsters_allocated;
    }
    public static ArrayList<Integer>[] getMap() {
        return map;
    }
    public static int calc_best_location(int x){
        int min=4;
        int location = x;
        for (int i=0;i<Game_Layout.getMap()[x].size();i++){
            if (Game_Layout.getMonsters_allocated()[Game_Layout.getMap()[x].get(i)]<min){
                min=Game_Layout.getMonsters_allocated()[Game_Layout.getMap()[x].get(i)];
                location = Game_Layout.getMap()[x].get(i);
            }
        }
        return location;
    }
}

abstract class Sidekick implements Cloneable{
    protected static ArrayList<Sidekick> all_sidekicks = new ArrayList<>();
    protected float xp=0;
    protected float hp=100;
    protected final float initial_hp = 100;
    protected float attack=0;
    protected boolean abilitiy_used = false;
    Sidekick(float attack){
        this.attack = attack;
    }
    public static void add_sidekick(Sidekick x){
        all_sidekicks.add(x);
    }
    public float getXp() {
        return xp;
    }
    public float getHp() {
        return hp;
    }
    public void setXp(int xp){
        this.xp+=xp;
        this.hp=initial_hp;
    }
    public void setHp(float hp) {
        this.hp -= hp;
    }
    public float getAttack(){ return this.attack;}
    public abstract float Attack(String use_ability);
    public static ArrayList<Sidekick> getAll_sidekicks() {
        return all_sidekicks;
    }
    public boolean getAbility_used(){ return this.abilitiy_used;}
    public void setAbilitiy_used(boolean abilitiy_used) {
        this.abilitiy_used = abilitiy_used;
    }
    @Override
    public Minion clone() {
        try {
            Minion copy = (Minion) super.clone();
            return copy;
        }catch(CloneNotSupportedException e){
            return null;
        }
        //return copy;
    }
}

class Minion extends Sidekick {
    Minion(float attack){
        super(attack);
    }
    public float Attack(String use_ability){
        System.out.println("Sidekick attacked and inflicted "+this.attack+" damage to the opponent");
        return this.attack;
    }
}

class Knight extends Sidekick{
    Knight(float attack){
        super(attack);
    }
    public float Attack(String use_ability){
        return this.attack;
    }
}
